
global.owner = {
ownername: "prastzy!",
ownernumber: ["62895365459805"],
botname: "FANATIC V2 VIP",
botnumber: "62895365459805", 
version: "v2.0.0",
session: "session",
wm: "FANATIK - PrsTzyy"
}
//---===================================//